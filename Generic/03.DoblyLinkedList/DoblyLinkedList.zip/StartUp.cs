﻿using System;

namespace _03.DoblyLinkedList
{
   public class StartUp
    {
       public static void Main(string[] args)
        {
           
        }
    }
}
