﻿using System;

namespace _07.CustomLinkedList
{
   public class Program
    {
      public  static void Main(string[] args)
        {
            
        }
    }
}
